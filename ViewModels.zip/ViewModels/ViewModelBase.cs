﻿using ReactiveUI;

namespace Calc.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}