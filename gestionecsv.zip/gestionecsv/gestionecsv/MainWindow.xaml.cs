﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Linq;


namespace gestionecsv
{
    public class Song
    {
        public double SongLength { get; set; }
        public int NumInstruments { get; set; }
        public string Genre { get; set; }
        public double Tempo { get; set; }
        public double LyricalContent { get; set; }
        public int ReleasedYear { get; set; }
        public int Popularity { get; set; }
    }
    public partial class MainWindow : Window
    {
        private List<Song> songList;

        public MainWindow()
        {
            InitializeComponent();
            songList = new List<Song>();
            LoadCsvData("sample_submission.csv"); 
            SongDataGrid.ItemsSource = songList;
        }

        private void LoadCsvData(string fileName)
        {
            try
            {
                string directoryPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string filePath = Path.Combine(directoryPath, fileName);

                if (!File.Exists(filePath))
                {
                    MessageBox.Show($"Il file {fileName} non è stato trovato nella cartella dell'applicazione.", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                using (var reader = new StreamReader(filePath))
                {
                    songList.Clear();
                    bool firstLine = true;

                    while (!reader.EndOfStream)
                    {
                        var line = reader.ReadLine();
                        var values = line.Split(',');

                        if (values.Length == 7)
                        {
                            try
                            {
                                if (firstLine)
                                {
                                    
                                    firstLine = false;
                                    continue;
                                }

                                var song = new Song
                                {
                                    SongLength = Convert.ToDouble(values[0], CultureInfo.InvariantCulture),
                                    NumInstruments = Convert.ToInt32(values[1]),
                                    Genre = values[2],
                                    Tempo = Convert.ToDouble(values[3], CultureInfo.InvariantCulture),
                                    LyricalContent = Convert.ToDouble(values[4], CultureInfo.InvariantCulture),
                                    ReleasedYear = Convert.ToInt32(values[5]),
                                    Popularity = Convert.ToInt32(values[6])
                                };

                                songList.Add(song);
                            }
                            catch (FormatException ex)
                            {
                                MessageBox.Show($"Errore nella riga: {line}. Verifica i dati numerici. Dettagli: {ex.Message}", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show($"La riga nel file CSV non ha il numero corretto di colonne.", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Si è verificato un errore durante il caricamento del file CSV: {ex.Message}", "Errore", MessageBoxButton.OK, MessageBoxImage.Error);
            }
           

        }
        private void CalculateStatistics_Clicked(object sender, RoutedEventArgs e)
        {
            if (songList.Count == 0)
            {
                MessageBox.Show("La lista delle canzoni è vuota.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Filtra i valori validi nella colonna "Popularity"
            var validPopularityValues = songList.Where(song => song.Popularity != 0).Select(song => song.Popularity).ToList();

            if (validPopularityValues.Count == 0)
            {
                MessageBox.Show("La colonna 'Popularity' non contiene valori validi per il calcolo.", "Attenzione", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Calcola la moda
            List<int> modes = CalculateMode(validPopularityValues);

            // Calcola la media

            double average = validPopularityValues.Average();

            // Calcola la mediana
            double median = CalculateMedian(validPopularityValues);

            // Aggiorna le etichette con i risultati
            ModaText.Text = modes.Count > 0 ? string.Join(", ", modes) : "Nessuna moda";
            MediaText.Text = average.ToString();
            MedianaText.Text = median.ToString();
        }

        private List<int> CalculateMode(List<int> values)
        {
            var popularityCounts = new Dictionary<int, int>();

            // Conta le occorrenze di ciascun valore
            foreach (var value in values)
            {
                if (popularityCounts.ContainsKey(value))
                {
                    popularityCounts[value]++;
                }
                else
                {
                    popularityCounts[value] = 1;
                }
            }

            // Trova il massimo numero di occorrenze
            int maxCount = popularityCounts.Values.Max();

            // Se non ci sono ripetizioni, restituisci una lista vuota
            if (maxCount == 1)
            {
                return new List<int>();
            }

            // Trova i valori con il massimo numero di occorrenze
            var modes = popularityCounts.Where(kv => kv.Value == maxCount).Select(kv => kv.Key).ToList();

            return modes;
        }

        private double CalculateMedian(List<int> values)
        {
            var sortedList = values.OrderBy(value => value).ToList();
            int count = sortedList.Count;

            // Se il numero di elementi è dispari, restituisci il valore centrale
            if (count % 2 != 0)
            {
                int middleIndex = count / 2;
                double median = sortedList[middleIndex];
                return median;
            }
            else
            {
                // Se il numero di elementi è pari, calcola la media dei due valori centrali
                int middleIndex1 = count / 2 - 1;
                int middleIndex2 = count / 2;
                double median = (sortedList[middleIndex1] + sortedList[middleIndex2]) / 2.0;
                return median;
            }
        }
    }
} 