namespace Calc.Models;

public enum Operator
{
    Add,
    Subtract,
    Multiply,
    Divide
}